package com.example.projektmulti1

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.AttributeSet
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import java.lang.StringBuilder
//zmienne globalne
var JSON=""
var wpiszMiejscowosc="Warszawa";
var description="";
var icon="";
var sunrise="";
var sunset="";
var temp="";
var pressure="";
var timezone="";
var name="";
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onCreateView(name: String, context: Context, attrs: AttributeSet): View? {
        //funkcja pobierająca jsona ze strony internetowej i aktualizująca dane o pogodzie
        apiCall();
        return super.onCreateView(name, context, attrs)
    }
    //wyciągnięcie danych ze Stringa
private fun liczenie(index:Int,json:String): String {
    var index1=index;
    var description="";
    for (i in 1..40) {
        if(json[index1]=='"'||json[index1]==','||json[index1]=='}'){
            break;
        }
        description=description+json[index1].toString();
        index1++;

    }
    return description;
}
private fun apiCall(){
    //url strona na ktorej znajduje sie JSONA
var url="https://api.openweathermap.org/data/2.5/weather?q="+ wpiszMiejscowosc+",pl&APPID=7838047c948418ca8341fda1c72ba3f8"
        //wykorzystanie biblioteki volley
    val queue=Volley.newRequestQueue(this)

        val jsonObjectRequest=JsonObjectRequest(
            Request.Method.GET,url,null,
            {
                Log.d("wtf","Api call succesful")
JSON=it.toString();
                var index1 = JSON.indexOf("description")+14
                var index2 = JSON.indexOf("icon")+7
                var index3 = JSON.indexOf("sunrise")+9
                var index4 = JSON.indexOf("sunset")+8
                var index5 = JSON.indexOf("temp")+6
                var index6 = JSON.indexOf("pressure")+10
                var index7 = JSON.indexOf("timezone")+10
                var index8 = JSON.indexOf("name")+7
                description=liczenie(index1,JSON);
                icon=liczenie(index2,JSON);
                sunrise=liczenie(index3,JSON);
                sunset=liczenie(index4,JSON);
                temp=liczenie(index5,JSON);
                pressure=liczenie(index6,JSON);
                timezone=liczenie(index7,JSON);
                name=liczenie(index8,JSON);
            }, {
                Log.d("TAG","Api call failes")
            }
        )
        queue.add(jsonObjectRequest)
    }
}